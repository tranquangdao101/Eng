/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Admin
 */
public class Lop {
    
    private int l_ma;
    private String l_ten;
    private String l_trangthai;
    private String l_datebatdau;
    private String l_dateketthuc;
    private String l_trinhdo;
    private int l_sobuoi;

    public int getL_ma() {
        return l_ma;
    }

    public String getL_ten() {
        return l_ten;
    }

    public String getL_trangthai() {
        return l_trangthai;
    }

    public String getL_datebatdau() {
        return l_datebatdau;
    }

    public String getL_dateketthuc() {
        return l_dateketthuc;
    }

    public String getL_trinhdo() {
        return l_trinhdo;
    }

    public int getL_sobuoi() {
        return l_sobuoi;
    }

    public void setL_ma(int l_ma) {
        this.l_ma = l_ma;
    }

    public void setL_ten(String l_ten) {
        this.l_ten = l_ten;
    }

    public void setL_trangthai(String l_trangthai) {
        this.l_trangthai = l_trangthai;
    }

    public void setL_datebatdau(String l_datebatdau) {
        this.l_datebatdau = l_datebatdau;
    }

    public void setL_dateketthuc(String l_dateketthuc) {
        this.l_dateketthuc = l_dateketthuc;
    }

    public void setL_trinhdo(String l_trinhdo) {
        this.l_trinhdo = l_trinhdo;
    }

    public void setL_sobuoi(int l_sobuoi) {
        this.l_sobuoi = l_sobuoi;
    }

    public Lop(int l_ma, String l_ten, String l_trangthai, String l_datebatdau, String l_dateketthuc, String l_trinhdo, int l_sobuoi) {
        this.l_ma = l_ma;
        this.l_ten = l_ten;
        this.l_trangthai = l_trangthai;
        this.l_datebatdau = l_datebatdau;
        this.l_dateketthuc = l_dateketthuc;
        this.l_trinhdo = l_trinhdo;
        this.l_sobuoi = l_sobuoi;
    }
    public Lop(){
        
    }
}
