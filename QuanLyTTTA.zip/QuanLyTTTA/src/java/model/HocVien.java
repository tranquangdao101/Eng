/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Admin
 */
public class HocVien {

    private String hv_hoten;
    private String hv_sodt;
    private String hv_email;
    private String hv_quequan;
    private int hv_diem;
    private String k_ten;
    private String l_ten;
    private int hp_ma;
    private String hp_datenop;
    private String hp_thanhtoan;
    private String hp_ghichu;
    private int k_hocphi;

    public void setK_hocphi(int k_hocphi) {
        this.k_hocphi = k_hocphi;
    }

    public int getK_hocphi() {
        return k_hocphi;
    }
    

    public String getHv_hoten() {
        return hv_hoten;
    }

    public String getHv_sodt() {
        return hv_sodt;
    }

    public String getHv_email() {
        return hv_email;
    }

    public String getHv_quequan() {
        return hv_quequan;
    }

    public int getHv_diem() {
        return hv_diem;
    }

  

    public HocVien() {

    }

    public void setHv_hoten(String hv_hoten) {
        this.hv_hoten = hv_hoten;
    }

    public void setHv_sodt(String hv_sodt) {
        this.hv_sodt = hv_sodt;
    }

    public void setHv_email(String hv_email) {
        this.hv_email = hv_email;
    }

    public void setHv_quequan(String hv_quequan) {
        this.hv_quequan = hv_quequan;
    }

    public void setHv_diem(int hv_diem) {
        this.hv_diem = hv_diem;
    }

    public String getK_ten() {
        return k_ten;
    }

    public String getL_ten() {
        return l_ten;
    }

    public int getHp_ma() {
        return hp_ma;
    }

    public String getHp_datenop() {
        return hp_datenop;
    }

    public String getHp_thanhtoan() {
        return hp_thanhtoan;
    }

    public String getHp_ghichu() {
        return hp_ghichu;
    }

    public void setK_ten(String k_ten) {
        this.k_ten = k_ten;
    }

    public void setL_ten(String l_ten) {
        this.l_ten = l_ten;
    }

    public void setHp_ma(int hp_ma) {
        this.hp_ma = hp_ma;
    }

    public void setHp_datenop(String hp_datenop) {
        this.hp_datenop = hp_datenop;
    }

    public void setHp_thanhtoan(String hp_thanhtoan) {
        this.hp_thanhtoan = hp_thanhtoan;
    }

    public void setHp_ghichu(String hp_ghichu) {
        this.hp_ghichu = hp_ghichu;
    }

    public HocVien(String hv_hoten, String hv_sodt, String hv_email, String hv_quequan, int hv_diem, String k_ten, String l_ten, int k_hocphi) {
        this.hv_hoten = hv_hoten;
        this.hv_sodt = hv_sodt;
        this.hv_email = hv_email;
        this.hv_quequan = hv_quequan;
        this.hv_diem = hv_diem;
        this.k_ten = k_ten;
        this.l_ten = l_ten;
        this.k_hocphi = k_hocphi;
    }

    public HocVien(String hv_hoten, String hv_sodt, String hv_email, String hv_quequan, int hv_diem) {
        this.hv_hoten = hv_hoten;
        this.hv_sodt = hv_sodt;
        this.hv_email = hv_email;
        this.hv_quequan = hv_quequan;
        this.hv_diem = hv_diem;
    }

   

}
