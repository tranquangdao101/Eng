/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Admin
 */
public class KhachHang {
    private int kh_ma;
    private String kh_tieude;

    public KhachHang(int kh_ma, String kh_tieude, String kh_nguoigui, String kh_email, String kh_datengaygui, String kh_noidung, byte kh_tinhtang) {
        this.kh_ma = kh_ma;
        this.kh_tieude = kh_tieude;
        this.kh_nguoigui = kh_nguoigui;
        this.kh_email = kh_email;
        this.kh_datengaygui = kh_datengaygui;
        this.kh_noidung = kh_noidung;
        this.kh_tinhtang = kh_tinhtang;
    }

    public void setKh_tieude(String kh_tieude) {
        this.kh_tieude = kh_tieude;
    }

    public String getKh_tieude() {
        return kh_tieude;
    }
    private String kh_nguoigui;
    private String kh_email;
    private String kh_datengaygui;
    private String kh_noidung;
    private byte kh_tinhtang;

    public int getKh_ma() {
        return kh_ma;
    }

    public String getKh_nguoigui() {
        return kh_nguoigui;
    }

    public String getKh_email() {
        return kh_email;
    }

    public String getKh_datengaygui() {
        return kh_datengaygui;
    }

    public String getKh_noidung() {
        return kh_noidung;
    }

    public byte getKh_tinhtang() {
        return kh_tinhtang;
    }

    public void setKh_ma(int kh_ma) {
        this.kh_ma = kh_ma;
    }

    public void setKh_nguoigui(String kh_nguoigui) {
        this.kh_nguoigui = kh_nguoigui;
    }

    public void setKh_email(String kh_email) {
        this.kh_email = kh_email;
    }

    public void setKh_datengaygui(String kh_datengaygui) {
        this.kh_datengaygui = kh_datengaygui;
    }

    public void setKh_noidung(String kh_noidung) {
        this.kh_noidung = kh_noidung;
    }

    public void setKh_tinhtang(byte kh_tinhtang) {
        this.kh_tinhtang = kh_tinhtang;
    }

    public KhachHang(int kh_ma, String kh_nguoigui, String kh_email, String kh_datengaygui, String kh_noidung, byte kh_tinhtang) {
        this.kh_ma = kh_ma;
        this.kh_nguoigui = kh_nguoigui;
        this.kh_email = kh_email;
        this.kh_datengaygui = kh_datengaygui;
        this.kh_noidung = kh_noidung;
        this.kh_tinhtang = kh_tinhtang;
    }
    public KhachHang(){
        
    }
    }
