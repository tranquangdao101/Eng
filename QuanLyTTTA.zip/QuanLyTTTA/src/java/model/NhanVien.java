/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Admin
 */
public class NhanVien {
    private String nv_hoten;
    private String nv_tendangnhap;
    private String nv_matkhau;
    private int role;
    private int loaiNV;

    public NhanVien(String nv_hoten, String nv_tendangnhap, String nv_matkhau, int role, int loaiNV, String nv_sodt, String nv_email, String nv_quequan) {
        this.nv_hoten = nv_hoten;
        this.nv_tendangnhap = nv_tendangnhap;
        this.nv_matkhau = nv_matkhau;
        this.role = role;
        this.loaiNV = loaiNV;
        this.nv_sodt = nv_sodt;
        this.nv_email = nv_email;
        this.nv_quequan = nv_quequan;
    }

    public int getLoaiNV() {
        return loaiNV;
    }

    public void setLoaiNV(int loaiNV) {
        this.loaiNV = loaiNV;
    }
    
    public NhanVien(){
        
    }
    public NhanVien( String nv_hoten, String nv_tendangnhap, String nv_matkhau, int role, String nv_sodt, String nv_email, String nv_quequan) {
        this.nv_hoten = nv_hoten;
        this.nv_tendangnhap = nv_tendangnhap;
        this.nv_matkhau = nv_matkhau;
        this.role = role;
        this.nv_sodt = nv_sodt;
        this.nv_email = nv_email;
        this.nv_quequan = nv_quequan;
    }

    public void setRole(int role) {
        this.role = role;
    }

    public int getRole() {
        return role;
    }

    public NhanVien( String nv_hoten, String nv_tendangnhap, String nv_matkhau, String nv_sodt, String nv_email, String nv_quequan) {
        this.nv_hoten = nv_hoten;
        this.nv_tendangnhap = nv_tendangnhap;
        this.nv_matkhau = nv_matkhau;
        this.nv_sodt = nv_sodt;
        this.nv_email = nv_email;
        this.nv_quequan = nv_quequan;
    }


    public void setNv_hoten(String nv_hoten) {
        this.nv_hoten = nv_hoten;
    }

    public void setNv_tendangnhap(String nv_tendangnhap) {
        this.nv_tendangnhap = nv_tendangnhap;
    }

    public void setNv_matkhau(String nv_matkhau) {
        this.nv_matkhau = nv_matkhau;
    }

    public void setNv_sodt(String nv_sodt) {
        this.nv_sodt = nv_sodt;
    }

    public void setNv_email(String nv_email) {
        this.nv_email = nv_email;
    }

    public void setNv_quequan(String nv_quequan) {
        this.nv_quequan = nv_quequan;
    }



    public String getNv_hoten() {
        return nv_hoten;
    }

    public String getNv_tendangnhap() {
        return nv_tendangnhap;
    }

    public String getNv_matkhau() {
        return nv_matkhau;
    }

    public String getNv_sodt() {
        return nv_sodt;
    }

    public String getNv_email() {
        return nv_email;
    }

    public String getNv_quequan() {
        return nv_quequan;
    }
    private String nv_sodt;
    private String nv_email;
    private String nv_quequan;

}
