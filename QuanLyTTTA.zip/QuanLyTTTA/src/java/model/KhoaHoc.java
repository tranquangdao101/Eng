/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Admin
 */
public class KhoaHoc {
    
    private int k_ma;
    private String k_ten;
    private int k_hocphi;
    private String k_chitiet;

    public int getK_ma() {
        return k_ma;
    }

    public String getK_ten() {
        return k_ten;
    }

    public int getK_hocphi() {
        return k_hocphi;
    }

    public String getK_chitiet() {
        return k_chitiet;
    }

    public void setK_ma(int k_ma) {
        this.k_ma = k_ma;
    }

    public void setK_ten(String k_ten) {
        this.k_ten = k_ten;
    }

    public void setK_hocphi(int k_hocphi) {
        this.k_hocphi = k_hocphi;
    }

    public void setK_chitiet(String k_chitiet) {
        this.k_chitiet = k_chitiet;
    }

    public KhoaHoc(int k_ma, String k_ten, int k_hocphi, String k_chitiet) {
        this.k_ma = k_ma;
        this.k_ten = k_ten;
        this.k_hocphi = k_hocphi;
        this.k_chitiet = k_chitiet;
    }

    public KhoaHoc() {
    }
    
}
