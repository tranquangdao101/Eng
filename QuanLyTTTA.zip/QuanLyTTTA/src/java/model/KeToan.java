/*
 * To change this license header; choose License Headers in Project Properties.
 * To change this template file; choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Admin
 */
public class KeToan {

    String nv_hoten;
    String nv_tendangnhap;
    String nv_matkhau;
    String nv_sdt;
    String nv_email;
    String nv_quequan;
    byte nv_hopdong;
    String cc_ngaythang;
    byte cc_1;
    byte cc_2;
    byte cc_3;
    byte cc_4;
    byte cc_5;
    byte cc_6;
    byte cc_7;
    byte cc_8;
    byte cc_9;
    byte cc_10;
    byte cc_11;
    byte cc_12;
    byte cc_13;
    byte cc_14;
    byte cc_15;
    byte cc_16;
    byte cc_17;
    byte cc_18;
    byte cc_19;
    byte cc_20;
    byte cc_21;
    byte cc_22;
    byte cc_23;
    byte cc_24;
    byte cc_25;
    byte cc_26;
    byte cc_27;
    byte cc_28;
    byte cc_29;
    byte cc_30;
    byte cc_31;
    
    public KeToan(){
        
    }

    public void setNv_hoten(String nv_hoten) {
        this.nv_hoten = nv_hoten;
    }

    public void setNv_tendangnhap(String nv_tendangnhap) {
        this.nv_tendangnhap = nv_tendangnhap;
    }

    public void setNv_matkhau(String nv_matkhau) {
        this.nv_matkhau = nv_matkhau;
    }

    public void setNv_sdt(String nv_sdt) {
        this.nv_sdt = nv_sdt;
    }

    public void setNv_email(String nv_email) {
        this.nv_email = nv_email;
    }

    public void setNv_quequan(String nv_quequan) {
        this.nv_quequan = nv_quequan;
    }

    public void setNv_hopdong(byte nv_hopdong) {
        this.nv_hopdong = nv_hopdong;
    }

    public void setCc_ngaythang(String cc_ngaythang) {
        this.cc_ngaythang = cc_ngaythang;
    }

    public void setCc_1(byte cc_1) {
        this.cc_1 = cc_1;
    }

    public void setCc_2(byte cc_2) {
        this.cc_2 = cc_2;
    }

    public void setCc_3(byte cc_3) {
        this.cc_3 = cc_3;
    }

    public void setCc_4(byte cc_4) {
        this.cc_4 = cc_4;
    }

    public void setCc_5(byte cc_5) {
        this.cc_5 = cc_5;
    }

    public void setCc_6(byte cc_6) {
        this.cc_6 = cc_6;
    }

    public void setCc_7(byte cc_7) {
        this.cc_7 = cc_7;
    }

    public void setCc_8(byte cc_8) {
        this.cc_8 = cc_8;
    }

    public void setCc_9(byte cc_9) {
        this.cc_9 = cc_9;
    }

    public void setCc_10(byte cc_10) {
        this.cc_10 = cc_10;
    }

    public void setCc_11(byte cc_11) {
        this.cc_11 = cc_11;
    }

    public void setCc_12(byte cc_12) {
        this.cc_12 = cc_12;
    }

    public void setCc_13(byte cc_13) {
        this.cc_13 = cc_13;
    }

    public void setCc_14(byte cc_14) {
        this.cc_14 = cc_14;
    }

    public void setCc_15(byte cc_15) {
        this.cc_15 = cc_15;
    }

    public void setCc_16(byte cc_16) {
        this.cc_16 = cc_16;
    }

    public void setCc_17(byte cc_17) {
        this.cc_17 = cc_17;
    }

    public void setCc_18(byte cc_18) {
        this.cc_18 = cc_18;
    }

    public void setCc_19(byte cc_19) {
        this.cc_19 = cc_19;
    }

    public void setCc_20(byte cc_20) {
        this.cc_20 = cc_20;
    }

    public void setCc_21(byte cc_21) {
        this.cc_21 = cc_21;
    }

    public void setCc_22(byte cc_22) {
        this.cc_22 = cc_22;
    }

    public void setCc_23(byte cc_23) {
        this.cc_23 = cc_23;
    }

    public void setCc_24(byte cc_24) {
        this.cc_24 = cc_24;
    }

    public void setCc_25(byte cc_25) {
        this.cc_25 = cc_25;
    }

    public void setCc_26(byte cc_26) {
        this.cc_26 = cc_26;
    }

    public void setCc_27(byte cc_27) {
        this.cc_27 = cc_27;
    }

    public void setCc_28(byte cc_28) {
        this.cc_28 = cc_28;
    }

    public void setCc_29(byte cc_29) {
        this.cc_29 = cc_29;
    }

    public void setCc_30(byte cc_30) {
        this.cc_30 = cc_30;
    }

    public void setCc_31(byte cc_31) {
        this.cc_31 = cc_31;
    }

    public String getNv_hoten() {
        return nv_hoten;
    }

    public String getNv_tendangnhap() {
        return nv_tendangnhap;
    }

    public String getNv_matkhau() {
        return nv_matkhau;
    }

    public String getNv_sdt() {
        return nv_sdt;
    }

    public String getNv_email() {
        return nv_email;
    }

    public String getNv_quequan() {
        return nv_quequan;
    }

    public byte getNv_hopdong() {
        return nv_hopdong;
    }

    public String getCc_ngaythang() {
        return cc_ngaythang;
    }

    public byte getCc_1() {
        return cc_1;
    }

    public byte getCc_2() {
        return cc_2;
    }

    public byte getCc_3() {
        return cc_3;
    }

    public byte getCc_4() {
        return cc_4;
    }

    public byte getCc_5() {
        return cc_5;
    }

    public byte getCc_6() {
        return cc_6;
    }

    public byte getCc_7() {
        return cc_7;
    }

    public byte getCc_8() {
        return cc_8;
    }

    public byte getCc_9() {
        return cc_9;
    }

    public byte getCc_10() {
        return cc_10;
    }

    public byte getCc_11() {
        return cc_11;
    }

    public byte getCc_12() {
        return cc_12;
    }

    public byte getCc_13() {
        return cc_13;
    }

    public byte getCc_14() {
        return cc_14;
    }

    public byte getCc_15() {
        return cc_15;
    }

    public byte getCc_16() {
        return cc_16;
    }

    public byte getCc_17() {
        return cc_17;
    }

    public byte getCc_18() {
        return cc_18;
    }

    public byte getCc_19() {
        return cc_19;
    }

    public byte getCc_20() {
        return cc_20;
    }

    public byte getCc_21() {
        return cc_21;
    }

    public byte getCc_22() {
        return cc_22;
    }

    public byte getCc_23() {
        return cc_23;
    }

    public byte getCc_24() {
        return cc_24;
    }

    public byte getCc_25() {
        return cc_25;
    }

    public byte getCc_26() {
        return cc_26;
    }

    public byte getCc_27() {
        return cc_27;
    }

    public byte getCc_28() {
        return cc_28;
    }

    public byte getCc_29() {
        return cc_29;
    }

    public byte getCc_30() {
        return cc_30;
    }

    public byte getCc_31() {
        return cc_31;
    }
}
